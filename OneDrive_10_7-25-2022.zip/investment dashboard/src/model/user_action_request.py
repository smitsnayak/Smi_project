from typing import Optional, Dict
from pydantic import BaseModel, Field
from typing import Optional, Dict, List
class UserActionRequest(BaseModel):
    inv_id: str
    tradingsymbol: str
    exchange: str
    transaction_type: str
    order_type: str
    quantity: float
    product: str
    validity: str

class PlaceOrdersList(BaseModel):
    market_orders : List[UserActionRequest]
