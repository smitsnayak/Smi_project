from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import exc
from src.util.generic_logger import GenericLogger
from sqlalchemy.ext.declarative import declarative_base


class DBConnection:

    @staticmethod
    def get_db_sessionmaker(sqlalchemy_db_url):
        try:

            engine = create_engine(sqlalchemy_db_url)
        except exc.SQLAlchemyError as err:
            GenericLogger.loggit.log(40,'unable to establish engine connection-{}'.format(err))
        try:
            session_local = sessionmaker(autocommit=False, autoflush=False,
                                         bind=engine)
            session_object = session_local()
        except exc.SQLAlchemyError as e:
            GenericLogger.loggit.log(40,'unable to establish session-{}'.format(e))

        return session_object,engine

    @staticmethod
    def get_conn_engine(sqlalchemy_db_url):
        try:
            conn_engine = create_engine(sqlalchemy_db_url)
        except exc.SQLAlchemyError as err:
            GenericLogger.loggit.log(40,'unable to establish engine connection-{}'.format(err))
        return conn_engine

    @staticmethod
    def get_base_declarative():
        Base = declarative_base()
        return Base