from typing import Optional, Dict
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, Dict, List
class UserActionResponse(BaseModel):
    order_id:str
    parent_order_id:str
    exchange_order_id:str
    placed_by:str
    variety:str
    status:str
    tradingsymbol:str
    exchange:str
    instrument_token:str
    transaction_type:str
    order_type:str
    product:str
    validity:str
    price:float
    quantity:float
    trigger_price:float
    average_price:float
    pending_quantity:float
    filled_quantity:float
    disclosed_quantity:float
    order_timestamp:str
    exchange_update_timestamp:str
    status_message:str
    meta:str


class MarketOrderss(BaseModel):
    market_orders : List[UserActionResponse]