import _utils
import _stats
import io as _io
import datetime as _dt
import pandas as _pd
import numpy as _np
import yfinance as _yf
from datetime import (
    datetime as dt, timedelta as _td)

portfolio_list = ['AAPL',"MSFT"]
portfolio_weights = [0.5,0.5]


# portfolio_qty = [21,6,6]
# portfolio_list = ['TATAMOTORS.NS']
# portfolio_weights = [1]

benchmark_list = ['^GSPC']
benchmark_weights = [1]
initial_balance = 737669



############### GET Returns based on portfolio weights ###############
returns, individual_returns = _utils.ind_portfolio_based_returns(portfolio_list, portfolio_weights)

benchmark = _utils.benchmark_returns(benchmark_list)
# print(returns)
# print(_stats.greeks(returns, benchmark, periods=252., prepare_returns=True))
# print(portfolio_sector_list)
# daily_port = _stats.final_balances(individual_returns, initial_balance)
# daily_port.to_csv('daily_port.csv')


print(returns)
# inv_periodic_returns_data = _utils.performance_analysis_compsum(returns)
# print(inv_periodic_returns_data)
# inv_periodic_returns_data.to_csv('inv_periodic_returns_data.csv')
# ############### GET Portfolio and Sector Allocation ##############
# sector_allocation, asset_allocation, marketcap_allocation, return_allocation = (_stats.portfolio_sector_allocation(portfolio_list,portfolio_weights))
# sector_allocation.to_csv('inv_sector.csv')
# print(sector_allocation['weights'].sum()*100)
# asset_allocation.to_csv('inv_asset.csv')
# marketcap_allocation.to_csv('inv_marketcap.csv')
# draw = _stats.to_drawdown_series(returns)
# draw.to_csv('draw.csv')
################ GET Performance Analysis ################
pct = 100
# print('cagr',_stats.cagr(returns, rf=0, compounded=True)*pct)
# print('volatility',_stats.volatility(returns, periods=252, annualize=True, prepare_returns=True)*pct)
# print('best_year',_stats.best(returns, aggregate='year', compounded=True, prepare_returns=True)*pct)
# print('worst_year',_stats.worst(returns, aggregate='year', compounded=True, prepare_returns=True)*pct)
# print('max_drawdown',_stats.max_drawdown(returns)*pct)
# print('sharpe_ratio',_stats.sharpe(returns, rf=0, periods=252, annualize=True, smart=False))
# print('sortino_ratio',_stats.sortino(returns, rf=0, periods=252, annualize=True, smart=False))
# print(_stats.monthly_returns(returns, eoy=True, compounded=True, prepare_returns=True))
# # print('cumsum_returns',_stats.compsum(individual_returns)*pct)
# print('final_balance',_stats.final_balance(returns, initial_balance))
# print('performance_analysis',_utils.performance_analysis(returns))
# print(_stats.greeks(returns, benchmark, periods=252., prepare_returns=True))
# print("Daily_to_monthly",_stats.daily_to_monthly_returns(returns, eoy=True, compounded=True, prepare_returns=True))


# ################ GET Drawdown Analysis ################
# returnss = _stats.daily_to_monthly_returns(returns, eoy=True, compounded=True, prepare_returns=True)
# print(_stats.drawdown_analysis(returnss))
#
#
# ################ GET Individual Holdings ############
# print(_stats.individual_holdings_returns(individual_returns))
# print(_stats.individual_holdings_performance(individual_returns,initial_balance))
#
# ####################  GET Portfolio Holdings  ##########################
# print(_stats.individual_holdings_returns(returns))
# print(_stats.individual_holdings_performance(returns,initial_balance))
#
# ################### GET Compare Returns #######################
print(_stats.compare(returns, benchmark, aggregate='month', compounded=True,round_vals=None, prepare_returns=True))
print(_stats.compare(returns, benchmark, aggregate='year', compounded=True,round_vals=None, prepare_returns=True))