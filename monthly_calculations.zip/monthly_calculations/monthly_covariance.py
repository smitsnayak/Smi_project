import pandas as pd
import numpy as np


data = pd.read_csv("historical_monthly_returns.csv")

def monthly_covariance(data):
    pivoted = data.pivot(index='as_of_date', columns='instrument_symbol', values='adj_close_returns') \
        .reset_index()
    pivoted.columns.name = None

    pivoted_cov = pivoted.cov().unstack(level=1).reset_index()
    pivoted_cov.columns = ["instrument_symbol_1", "instrument_symbol_2", "covariance"]
    return pivoted_cov


print(monthly_covariance(data))