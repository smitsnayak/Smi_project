import pandas as pd
import numpy as np
import pingouin as pg


data = pd.read_csv("historical_monthly_returns.csv")
def monthly_correlation(data):
    pivoted = data.pivot(index='as_of_date', columns='instrument_symbol', values='adj_close_returns') \
        .reset_index()
    pivoted.columns.name = None

    pivoted_corr = pivoted.corr().unstack(level=1).reset_index()

    pivoted_corr.columns = ["instrument_symbol_1","instrument_symbol_2","correlation"]

    return pivoted_corr





print(monthly_correlation(data))