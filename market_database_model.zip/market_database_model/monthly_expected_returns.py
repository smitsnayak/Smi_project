from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Float, \
    BigInteger,Date
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

# Table Class
class MonthlyExpectedReturns(Base):
    __tablename__ = "monthly_expected_returns"
    __table_args__ = {"quote": False, "extend_existing": True,
                      "schema": "price_data"}

    csm_instrument_id = Column(BigInteger)
    instrument_symbol = Column(String)
    as_of_date = Column(Date)
    monthly_avg_returns = Column(Float)
    annualized_avg_exp_returns = Column(Float)



