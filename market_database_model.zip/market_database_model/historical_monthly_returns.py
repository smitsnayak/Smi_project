from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Float, \
    BigInteger,Date
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

# Table Class
class HistoricalMonthlyReturns(Base):
    __tablename__ = "historical_monthly_returns"
    __table_args__ = {"quote": False, "extend_existing": True,
                      "schema": "price_data"}



    csm_instrument_id = Column(BigInteger)
    as_of_date = Column(Date)
    instrument_symbol = Column(String)
    adj_close_returns = Column(Float)

