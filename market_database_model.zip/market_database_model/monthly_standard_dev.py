from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Float, \
    BigInteger,Date
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

# Table Class
class MonthlyStandardDev(Base):
    __tablename__ = "monthly_standard_dev"
    __table_args__ = {"quote": False, "extend_existing": True,
                      "schema": "price_data"}

    csm_instrument_id = Column(BigInteger)
    as_of_date = Column(Date)
    mean = Column(Float)
    standard_dev = Column(Float)
