from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Float, \
    BigInteger,Date
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

# Table Class
class HistoricalMonthlyPrice(Base):
    __tablename__ = "historical_monthly_price"
    __table_args__ = {"quote": False, "extend_existing": True,
                      "schema": "price_data"}

    date = Column(Date)
    csm_instrument_id = Column(BigInteger)
    instrument_symbol = Column(String)
    open = Column(Float)
    high = Column(Float)
    low = Column(Float)
    close = Column(Float)
    close_adj = Column(Float)
    volume = Column(Float)
    sl_key = Column(BigInteger)