from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Float, \
    BigInteger,Date
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

# Table Class
class MonthlyCovariance(Base):
    __tablename__ = "monthly_covariance"
    __table_args__ = {"quote": False, "extend_existing": True,
                      "schema": "price_data"}


    as_of_date = Column(Date)
    csm_instrument_id_1 = Column(BigInteger)
    instrument_symbol_1 = Column(String)
    csm_instrument_id_2 = Column(BigInteger)
    instrument_symbol_2 = Column(String)
    covariance = Column(Float)

