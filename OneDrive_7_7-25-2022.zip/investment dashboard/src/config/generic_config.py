import yaml
import os

class GenericConfig:

    def __init__(self):
        #current_dir = os.path.dirname(os.path.dirname(os.getcwd()))
        config_file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),'src','config.yml')
        config_file = open(config_file_path, 'r')
        self.config_dict = yaml.safe_load(config_file)



    def get_reference_db_connection_str(self):
        return self.config_dict['DatabaseDetails']['REFERENCE_DB']['conn_string']

    def get_market_db_connection_str(self):
        return self.config_dict['DatabaseDetails']['MARKET_DB']['conn_string']

    def get_model_portfolio_db_connection_str(self):
        return self.config_dict['DatabaseDetails']['MODEL_PORTFOLIO_DB']['conn_string']

    def get_investor_portfolio_db_connection_str(self):
        return self.config_dict['DatabaseDetails']['INVESTOR_PORTFOLIO_DB']['conn_string']

    def get_investor_db_connection_str(self):
        return self.config_dict['DatabaseDetails']['INVESTOR_DATA_DB']['conn_string']


