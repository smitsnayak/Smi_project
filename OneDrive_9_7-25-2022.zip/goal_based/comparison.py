import _utils
import _stats
import io as _io
import datetime as _dt
import pandas as _pd
import numpy as _np
import yfinance as _yf
from datetime import (
    datetime as _dt, timedelta as _td)
portfolio_list = ['MGV','BND']
portfolio_weights = [0.5,0.5]

benchmark_list = ['^GSPC']
benchmark_weights = [1]
initial_balance = 10000

returns, individual_returns = _utils.ind_portfolio_based_returns(portfolio_list, portfolio_weights)
benchmark, individual_returns_bn = _utils.ind_portfolio_based_returns(benchmark_list, benchmark_weights)


# benchmark = _utils.benchmark_returns(benchmark_list)

############### GET Returns based on portfolio weights ###############
def comparison_of_two_portfolio(returns,benchmark, initial_balance):
    ####################  GET Portfolio Holdings  ##########################
    port_returns = _stats.individual_holdings_returns(returns).T
    port_performance = _stats.individual_holdings_performance(returns,initial_balance).T

    ####################  GET Benchmark Portfolio Holdings  ##########################
    port_returns_bn = _stats.individual_holdings_returns(benchmark).T
    port_performance_bn = _stats.individual_holdings_performance(benchmark, initial_balance).T

    data_1 = _pd.concat([port_returns_bn, port_returns],axis=1)
    data_1.columns = ['Benchmark','Portfolio']

    data_2 = _pd.concat([port_performance_bn, port_performance], axis=1)
    data_2.columns = ['Benchmark', 'Portfolio']
    #################### GET Compare Returns #######################
    # print(_stats.monthly_returns(returns, eoy=False, compounded=True, prepare_returns=True))
    yearly = _stats.compare(returns, benchmark, aggregate='year', compounded=True,round_vals=None, prepare_returns=True)
    final_df = _pd.concat([data_1, data_2, yearly]).round(2)
    return final_df
    # return final_df.to_csv('final_df.csv')




print(comparison_of_two_portfolio(returns,benchmark, initial_balance))

#
# def get_drawdown(returns,benchmark):
#     ################ GET Drawdown Analysis ################
#     returnss = _stats.daily_to_monthly_returns(returns, eoy=True, compounded=True, prepare_returns=True)
#     returnss_bn = _stats.daily_to_monthly_returns(benchmark, eoy=True, compounded=True, prepare_returns=True)
#     dd_port = _stats.drawdown_analysis(returnss)
#     dd_bn = _stats.drawdown_analysis(returnss_bn)
#     data_1 = _pd.concat([dd_bn, dd_port],keys=['Benchmark','Portfolio'])
#     # data_1.to_csv('dd.csv')
#     return data_1
#
# def compare(returns, benchmark, aggregate=None, compounded=True,
#             round_vals=None, prepare_returns=True):
#     """
#     Compare returns to benchmark on a
#     day/week/month/quarter/year basis
#     """
#     if prepare_returns:
#         returns = _utils._prepare_returns(returns)
#     benchmark = _utils._prepare_benchmark(benchmark, returns.index)
#
#     data = _pd.DataFrame(data={
#         'Benchmark': _utils.aggregate_returns(
#             benchmark, aggregate, compounded) * 100,
#         'Portfolio': _utils.aggregate_returns(
#             returns, aggregate, compounded) * 100
#     })
#
#     if round_vals is not None:
#         return _np.round(data, round_vals)
#
#     return data
#
# def performance_attribution(portfolio_list, portfolio_weights, benchmark_list, benchmark_weights, aggregate=None, compounded=True, prepare_returns=True):
#     returns = _utils.portfolio_based_returns(portfolio_list, portfolio_weights)
#     benchmark = _utils.portfolio_based_returns(benchmark_list, benchmark_weights)
#
#     # if prepare_returns:
#     #     returns = _utils._prepare_returns(returns)
#     # benchmark = _utils._prepare_benchmark(benchmark, returns.index)
#
#     sector_allocation, asset_allocation, marketcap_allocation, return_allocation = (_stats.portfolio_sector_allocation(portfolio_list, portfolio_weights))
#     sector_allocation_bn, asset_allocation_bn, marketcap_allocation_bn, return_allocation_bn = (_stats.portfolio_sector_allocation(benchmark_list, benchmark_weights))
#     allo = _pd.merge(return_allocation,return_allocation_bn,left_on= 'sectors', right_on='sectors',how='outer')
#     allo.columns = ['portfolio_sector', 'portfolio_weights', 'portfolio_returns', 'benchmark_weights', 'benchmark_returns']
#     allo = allo.fillna(0)
#     allo['excess_returns'] = allo['portfolio_returns'] - allo['benchmark_returns']
#     allo['excess_weights'] = allo['portfolio_weights'] - allo['benchmark_weights']
#
#     overall_portfolio_return = allo['portfolio_returns'].sum()
#     overall_benchmark_return = allo['benchmark_returns'].sum()
#
#     allo['allocation_weight'] = allo['excess_weights'] * (allo['benchmark_returns'] - overall_benchmark_return)
#     allo['security_allocation'] = allo['portfolio_weights'] * allo['excess_returns']
#     allo['interaction'] = allo['excess_weights'] * allo['excess_returns']
#
#     allo['portfolio_benchmark_weights'] = _np.where(allo['portfolio_weights'] > allo['benchmark_weights'], 1, 0)
#     allo['portfolio_benchmark_returns'] = _np.where(allo['portfolio_returns'] > allo['benchmark_returns'],1,0)
#     allo['benchmark_total_bn_ret'] = _np.where(allo['benchmark_returns'] > overall_benchmark_return,1,0)
#
#     def performance_attribution_effect(allo):
#         allo['Allocation_comment'] = [""]*len(allo)
#         allo['Interaction_comment'] = [""] * len(allo)
#         for i in range(len(allo)):
# ############################### Allocation Effect #################################
#             if ((allo['portfolio_benchmark_weights'][i] == 1) and (allo['benchmark_total_bn_ret'][i] == 1)):
#                 allo['Allocation_comment'][i] = "The investment manager overallocated assets to a segment that outperformed the total benchmark."
#
#             if ((allo['portfolio_benchmark_weights'][i] == 1) and (allo['benchmark_total_bn_ret'][i] == 0)):
#                 allo['Allocation_comment'][i] = "The investment manager overallocated assets to a segment that underperformed the total benchmark."
#
#             if ((allo['portfolio_benchmark_weights'][i] == 0) and (allo['benchmark_total_bn_ret'][i] == 1)):
#                 allo['Allocation_comment'][i] = "The investment manager underallocated assets to a segment that outperformed the total benchmark."
#
#             if ((allo['portfolio_benchmark_weights'][i] == 0) and (allo['benchmark_total_bn_ret'][i] == 0)):
#                 allo['Allocation_comment'][i] = "The investment manager overallocated assets to a segment that underperformed the total benchmark."
#
# ############################ Interaction Effect ####################################
#             if ((allo['portfolio_benchmark_returns'][i] == 1) and (allo['portfolio_benchmark_weights'][i] == 1)):
#                 allo['Interaction_comment'][i] = "The investment manager exercised good selection and overallocated assets to that segment."
#
#             if ((allo['portfolio_benchmark_returns'][i] == 1) and (allo['portfolio_benchmark_weights'][i] == 0)):
#                 allo['Interaction_comment'][i] = "The investment manager overweighted the portfolio securities for a given segment, that segment underperformed against the benchmark return for the same segment."
#
#             if ((allo['portfolio_benchmark_returns'][i] == 0) and (allo['portfolio_benchmark_weights'][i] == 1)):
#                 allo['Interaction_comment'][i] = "The investment manager underweighted the segment with good selection. The manager exercised good selection but poor allocation."
#
#             if ((allo['portfolio_benchmark_returns'][i] == 0) and (allo['portfolio_benchmark_weights'][i] == 0)):
#                 allo['Interaction_comment'][i] = "The impact of the joint effects is positive because the manager decision to underweight a poor performing segment was a good decision."
#         allo['Selection_effect'] = _np.where(allo['portfolio_benchmark_returns'] == 1, "The investment manager made good decisions in selecting securities that, as a whole, outperformed similar securities in the benchmark. ","The investment manager made poor decisions in selecting securities that, as a whole, underperformed similar securities in the benchmark.")
#         allo = allo.drop(['portfolio_benchmark_weights', 'portfolio_benchmark_returns', 'benchmark_total_bn_ret'],
#                          axis=1)
#         return allo
#
#
#     allo_eff = performance_attribution_effect(allo)
#     # allo_eff.to_csv('allo.csv')
#     return allo_eff
# print(performance_attribution(portfolio_list, portfolio_weights, benchmark_list, benchmark_weights, aggregate='year'))