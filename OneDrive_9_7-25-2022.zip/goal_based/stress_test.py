import _utils
import _stats
import io as _io
import datetime as _dt
import pandas as _pd
import numpy as _np
import yfinance as _yf
import scipy.stats as scs
from scipy.stats import norm
from datetime import (datetime as _dt, timedelta as _td)
import matplotlib.pyplot as plt

portfolio_list = ['CAG','THS','VG','EHC','CONE','LH','M','SPY','VVV','BKSY']
portfolio_weights = [0.218175, 0.164541,0.129884,0.120189,0.107622,0.086775,0.083642,0.049076,0.031817,0.008281]
# portfolio_list = ['GOOG','CHTR','MSFT','CNI','V','CP','MCO','SPGI','GOOGL','BXP','UNP','INFO','ARE']
# portfolio_weights = [0.187671,0.179754,0.112173,0.108124,0.105929,0.086834,0.0555826,0.0487775,0.0394071,0.0335648,0.0267457,0.0106784,0.00475916]
# portfolio_list = ['UNH','HD','GS','MSFT','MCD','CRM','AMGN','V','BA','CAT','HON','AAPL','MMM','JNJ','AXP','NKE','PG','JPM','DIS','TRV','WMT','IBM','CVX','MRK','CSCO','KO','DOW','INTC','WBA','VZ']
# portfolio_weights = [0.0905,0.0736,0.0712,0.0603,0.0484,0.046,0.0408,0.0399,0.0374,0.0373,0.0373,0.0328,0.032,0.0309,0.0303,0.0297,0.0293,0.0291,0.0282,0.0281,0.0261,0.0245,0.0215,0.0138,0.0114,0.0107,0.0102,0.0096,0.0096,0.0094]


# portfolio_list = ['SPY','AOR','WBII','BND','XLI','XLF','MUNI']
# portfolio_weights = [0.3,0.16,0.14,0.12,0.08,0.08,0.06]

# portfolio_list = ['SPY','SH','AGG']
# portfolio_weights = [0.81,0.1,0.09]
# portfolio_list = ['VLXVX']
# portfolio_weights = [1]

# portfolio_list = ['SPY','VTSMX','MDBAX','XLP','BND','VTEB','AGG','MPHQX']
# portfolio_weights = [0.157,0.129,0.129,0.129,0.129,0.129,0.112,0.086]

# portfolio_list = ['MSFT','TSLA']
# portfolio_weights = [0.5,0.5]
benchmark_list = ['VTINX']
benchmark_weights = [1]
initial_balance = 10000

returns, individual_returns = _utils.ind_portfolio_based_returns(portfolio_list, portfolio_weights)
benchmark, individual_returns_bn = _utils.ind_portfolio_based_returns(benchmark_list, benchmark_weights)

def stress_period(returns,column_name='Portfolio'):
    stress = []
    stress_period = ['Financial Crisis 2007', 'Bear Market 2008', 'Bull Market 2103', 'Pandemic Covid 2020']
    for i in range(1):
        stress.append(_stats.value_at_risk(returns['2007-10-15':'2009-03-02'], sigma=1.64, confidence=75, prepare_returns=True)* _np.sqrt(len(returns['2007-10-15':'2009-03-02']))*100)
        stress.append(_stats.value_at_risk(returns['2008-01-01':'2008-12-31'], sigma=1.64, confidence=75, prepare_returns=True)* _np.sqrt(len(returns['2008-01-01':'2008-12-31']))*100)
        stress.append(_stats.value_at_risk(returns['2013-01-01':'2013-12-31'], sigma=1.64, confidence=5, prepare_returns=True)* _np.sqrt(len(returns['2013-01-01':'2013-12-31']))*100)
        stress.append(_stats.value_at_risk(returns['2020-02-20':'2020-03-23'], sigma=1.64, confidence=75, prepare_returns=True)* _np.sqrt(len(returns['2020-02-20':'2020-03-23']))*100)
    stress = [round(elem, 2) for elem in stress]
    df = _pd.DataFrame(data=stress,index=stress_period,columns=[column_name])
    return df
portfolio = stress_period(returns)
benchmark = stress_period(benchmark,column_name='benchmark')
stress_test = _pd.concat([portfolio,benchmark],axis=1)
print(stress_test)
# stress_test.to_csv('stress.csv')



def forward_risk_return(returns):
    risk = _stats.value_at_risk(returns, sigma=1.64, confidence=80, prepare_returns=True) * _np.sqrt(126) * 100
    up = _stats.value_at_risk(returns, sigma=1.64, confidence=10, prepare_returns=True) * _np.sqrt(126) * 100
    return risk, up

def risk_no(risk):
    if risk >= -32:
        return 95
    else:
        return int(-0.0011*(risk**3) - 0.1458*(risk**2) - 6.3387*(risk) + 4.8547)

risk, upside = forward_risk_return(returns)
print(risk_no(risk))

























