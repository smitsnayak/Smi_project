from fastapi import FastAPI
from src.router import ems
import uvicorn

def get_application() -> FastAPI:
    api = FastAPI(
        debug=True,
        title="EMS",
        description="EMS for user action ",
        version="1.0",
    )
    api.include_router(ems.router)
    return api


api = get_application()


# http://127.0.0.1:8060/docs
if __name__ == "__main__":
    uvicorn.run(api, host="localhost", port=8060)
