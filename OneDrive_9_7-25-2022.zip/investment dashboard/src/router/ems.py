from typing import Dict
import fastapi
import pandas as pd
from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy.orm import Session

from datetime import datetime

from src.config.generic_config import GenericConfig
from src.db.db_connection import DBConnection
from src.db.db_model.investor_model import cash_allocation_model,investor_portfolio,model_portfolio
from src.model.user_action_request import UserActionRequest, PlaceOrdersList
from src.model.user_action_response import UserActionResponse, MarketOrderss
from src.repository.investor_portfolio_repository.order_allocation_repository import DbProcessCashAllocationRequest

router = fastapi.APIRouter()
generic_config_obj = GenericConfig()
investor_db_str = generic_config_obj.get_investor_db_connection_str()
investor_data_session, investor_data_engine = DBConnection.get_db_sessionmaker(investor_db_str)
investor_portfolio_str = generic_config_obj.get_investor_portfolio_db_connection_str()
investor_portfolio_session, investor_portfolio_engine = DBConnection.get_db_sessionmaker(investor_portfolio_str)
app = FastAPI()


@router.post("/ems", tags=["get investor portfolio"], status_code=200, response_model= MarketOrderss)
async def inv_portfolio_pms(user_action_details: PlaceOrdersList) ->  MarketOrderss:
    users = user_action_details.dict()
    user = list(users.values())[0]
    df = pd.DataFrame(user)
    print(df)
    order_response = []

    for i in range(len(df)):
        action_response = {}
        action_response['order_id'] =  'xyz123'
        action_response['parent_order_id'] = 'null'
        action_response['placed_by'] = df.loc[i,'inv_id']
        action_response["exchange_order_id"] = "200000000000000"
        action_response['variety'] = 'regular'
        action_response['status'] = 'COMPLETE'
        action_response['tradingsymbol'] = df.loc[i,'tradingsymbol']
        action_response['exchange'] = df.loc[i,'exchange']
        action_response['instrument_token'] = '412675'
        action_response['transaction_type'] = df.loc[i,'transaction_type']
        action_response['order_type'] = df.loc[i,'order_type']
        action_response['product'] = df.loc[i, 'product']
        action_response['validity'] = df.loc[i, 'validity']
        action_response['price'] = 1234
        action_response['quantity'] = df.loc[i,'quantity']
        action_response['trigger_price'] = 120
        action_response['average_price'] = 123
        action_response['pending_quantity'] = 0
        action_response['filled_quantity'] = df.loc[i,'quantity']
        action_response['disclosed_quantity'] = 0
        action_response['order_timestamp'] = '2021-05-31 09:18:57'
        action_response['exchange_update_timestamp'] = '2021-05-31 09:18:58'
        action_response['status_message'] = 'complete'
        action_response['meta'] = 'null'

        order_response.append(action_response)
        print(order_response)
    print(action_response)
    print(order_response)
    orders_dict = {"market_orders": order_response}
    # print(orders_dict)
    market_orders = MarketOrders(**orders_dict)
    print(market_orders)

    return market_orders

